package api.technicalanalysis.json.rsi;

import api.technicalanalysis.json.Result;

public class Rsi {
	
	private Result result;

	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}

}
