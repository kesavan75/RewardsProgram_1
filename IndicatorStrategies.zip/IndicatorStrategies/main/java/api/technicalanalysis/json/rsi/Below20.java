package api.technicalanalysis.json.rsi;

import java.util.List;

public class Below20 {
	
	private List timestamp;
	
	private List close;

	public List getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(List timestamp) {
		this.timestamp = timestamp;
	}

	public List getClose() {
		return close;
	}

	public void setClose(List close) {
		this.close = close;
	}

}
