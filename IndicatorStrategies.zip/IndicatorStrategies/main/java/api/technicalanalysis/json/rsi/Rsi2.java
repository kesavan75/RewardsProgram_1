package api.technicalanalysis.json.rsi;

import api.technicalanalysis.json.Result;

public class Rsi2 {
	
	private Result result;

	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}

}
