package api.technicalanalysis.json.stochastics;

import api.technicalanalysis.json.Result;


public class Stochastics {
	
	private Result result;

	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}

}
