package api.technicalanalysis.json;


public class Main {
	
	
	private Strategies strategies;

	public Strategies getStrategies() {
		return strategies;
	}

	public void setStrategies(Strategies strategies) {
		this.strategies = strategies;
	} 

}
